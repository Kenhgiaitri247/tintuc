<?php
$lang["embed_media"] = "Embed Media";
$lang["add_iframe"] = "Add Iframe";